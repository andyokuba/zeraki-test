package com.zeraki.app.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeraki.app.model.Course;
import com.zeraki.app.model.Institution;
import com.zeraki.app.model.Student;
import com.zeraki.app.repository.CourseRepository;
import com.zeraki.app.repository.InstitutionRepository;
import com.zeraki.app.repository.StudentRepository;

@Service
public class ZerakiServiceImpl implements ZerakiService {

	// Injecting the various repositories
	@Autowired
	StudentRepository studentRepository;

	@Autowired
	InstitutionRepository institutionRepository;

	@Autowired
	CourseRepository courseRepository;

	// find institution using name
	@Override
	public Institution findInstitutionUsingName(String institutionName) {
		Institution institution = institutionRepository.findByInstitutionNameIgnoreCase(institutionName);
		return institution;
	}

	// save institution
	@Override
	public void saveInstitution(@Valid Institution institution) {
		institutionRepository.save(institution);
	}

	// finds all institutions
	@Override
	public List<Institution> findAllInstitutions() {
		List<Institution> institutions = institutionRepository.findAll();
		return institutions;
	}

	// find institution Using id
	@Override
	public Institution findUsingInstitutionId(int institutionId) {

		Institution institution = institutionRepository.findByInstitutionId(institutionId);
		return institution;
	}

	// delete institution
	@Override
	public void deleteInstitution(Institution institution) {

		institutionRepository.delete(institution);
	}

	// find course using course name
	@Override
	public Course findCourseUsingName(String courseName) {
		Course course = courseRepository.findCourseByCourseName(courseName);
		return course;
	}

	// save course
	@Override
	public void saveCourse(@Valid Course course) {
		courseRepository.save(course);
	}

	// find course using course Id
	@Override
	public Course findUsingCourseId(int courseId) {
		Course course = courseRepository.findByCourseId(courseId);
		return course;
	}

	// delete course
	@Override
	public void deleteCourse(Course course) {
		courseRepository.delete(course);

	}

	// save student
	@Override
	public void saveStudent(@Valid Student student) {

		studentRepository.save(student);

	}

	// find student using id
	@Override
	public Student findUsingStudentId(int studentId) {
		Student student = studentRepository.findByStudentId(studentId);
		return student;
	}

	// delete student
	@Override
	public void deleteStudent(Student student) {
		studentRepository.delete(student);
		;

	}

}
