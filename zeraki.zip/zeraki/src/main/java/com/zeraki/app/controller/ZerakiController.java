package com.zeraki.app.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.zeraki.app.model.Course;
import com.zeraki.app.model.Institution;
import com.zeraki.app.model.Student;
import com.zeraki.app.service.ZerakiService;

@Controller
public class ZerakiController {

	@Autowired
	ZerakiService zerakiService;

	// index page to the browser with list of institutions
	@RequestMapping("/")
	public String index(ModelMap modelMap) {

		List<Institution> institutions = zerakiService.findAllInstitutions();

		modelMap.addAttribute("institutions", institutions);
		return "index";
	}

	// processing back click to home page
	@RequestMapping("/logout")
	public String logout(ModelMap modelMap) {

		List<Institution> institutions = zerakiService.findAllInstitutions();

		modelMap.addAttribute("institutions", institutions);
		return "index";
	}

	// sending addInstitution page to the browser
	@RequestMapping("/addInstitution")
	public ModelAndView showAddInstitutionPage(@ModelAttribute("institution") Institution institution,
			BindingResult bindingResult, ModelMap modelMap) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addInstitutionPage");

		return modelAndView;
	}

	// edit institution
	@RequestMapping("/editInstitution")
	public String showEditInstitutionPage(@RequestParam("institutionId") int institutionId, ModelMap modelMap) {

		Institution institution = zerakiService.findUsingInstitutionId(institutionId);

		modelMap.addAttribute("institution", institution);

		return "editInstitutionPage";

	}

	// delete institution
	@RequestMapping("/deleteInstitution")
	public String deleteInstitution(@RequestParam("institutionId") int institutionId) {

		Institution institution = zerakiService.findUsingInstitutionId(institutionId);

		zerakiService.deleteInstitution(institution);

		return "redirect:/logout";

	}

	// sending courseList page to the browser
	@RequestMapping("/courseList")
	public String addCourse(@RequestParam("institutionId") int institutionId, ModelMap modelMap,
			HttpServletResponse response) {

		Cookie cookie = new Cookie("institutionId", String.valueOf(institutionId));
		response.addCookie(cookie);
		Institution institution = zerakiService.findUsingInstitutionId(institutionId);
		List<Course> courses = institution.getCourses();
		modelMap.addAttribute("courses", courses);

		return "courseListPage";
	}

	// sending courseList page to the browser for when refreshed
	@RequestMapping("/listCourses")
	public String listCourses(@CookieValue(value = "institutionId", defaultValue = "0") int institutionId,
			ModelMap modelMap, HttpServletResponse response) {

		Institution institution = zerakiService.findUsingInstitutionId(institutionId);
		List<Course> courses = institution.getCourses();
		modelMap.addAttribute("courses", courses);

		return "courseListPage";
	}

	// sending addCourse page to the browser
	@RequestMapping("/addCourse")
	public ModelAndView showAddCoursePage(@ModelAttribute("course") Course course, BindingResult bindingResult,
			ModelMap modelMap) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addCoursePage");

		return modelAndView;
	}

	// saving the course
	@RequestMapping("/saveCourse")
	public String saveCourse(@Valid @ModelAttribute("course") Course course, BindingResult bindingResult,
			ModelMap modelMap, @CookieValue(value = "institutionId", defaultValue = "0") int institutionId) {

		if (bindingResult.hasErrors()) {

			return "addCoursePage";
		} else {

			if (zerakiService.findCourseUsingName(course.getCourseName()) == null) {

				Institution institution = zerakiService.findUsingInstitutionId(institutionId);

				course.setInstitution(institution);

				zerakiService.saveCourse(course);
				return "redirect:/listCourses";
			} else {

				modelMap.addAttribute("msg", "Course already exists please use another name");
				return "addCoursePage";

			}

		}
	}

	// edit course
	@RequestMapping("/editCourse")
	public String showEditCoursePage(@RequestParam("courseId") int courseId, ModelMap modelMap,
			HttpServletResponse response) {

		Course course = zerakiService.findUsingCourseId(courseId);

		Cookie cookie = new Cookie("courseId", String.valueOf(courseId));

		response.addCookie(cookie);

		modelMap.addAttribute("course", course);

		return "editCoursePage";

	}

	// saving the course
	@RequestMapping("/editCourseAction")
	public String editCourseAction(@Valid @ModelAttribute("course") Course course, BindingResult bindingResult,
			ModelMap modelMap, @CookieValue(value = "courseId", defaultValue = "0") int courseId) {

		if (bindingResult.hasErrors()) {

			return "addCoursePage";
		} else {

			if (zerakiService.findCourseUsingName(course.getCourseName()) == null) {

				Course courseDb = zerakiService.findUsingCourseId(courseId);

				courseDb.setCourseName(course.getCourseName());

				zerakiService.saveCourse(courseDb);
				return "redirect:/listCourses";
			} else {

				modelMap.addAttribute("msg", "Course already exists please use another name");
				return "addCoursePage";

			}

		}
	}

	// delete course
	@RequestMapping("/deleteCourse")
	public String deleteCourse(@RequestParam("courseId") int courseId) {

		Course course = zerakiService.findUsingCourseId(courseId);

		zerakiService.deleteCourse(course);

		return "redirect:/listCourses";

	}

	// sending studentList page to the browser
	@RequestMapping("/studentList")
	public String listStudent(@RequestParam("courseId") int courseId, ModelMap modelMap, HttpServletResponse response) {

		Cookie cookie = new Cookie("courseId", String.valueOf(courseId));
		response.addCookie(cookie);
		Course course = zerakiService.findUsingCourseId(courseId);
		List<Student> students = course.getStudents();
		modelMap.addAttribute("students", students);

		return "studentListPage";
	}

	// sending addStudent page to the browser
	@RequestMapping("/addStudent")
	public ModelAndView showAddStudentPage(@ModelAttribute("student") Student student, BindingResult bindingResult,
			ModelMap modelMap) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addStudentPage");

		return modelAndView;
	}

	// saving the student
	@RequestMapping("/saveStudent")
	public String saveStudent(@Valid @ModelAttribute("student") Student student, BindingResult bindingResult,
			ModelMap modelMap, @CookieValue(value = "institutionId", defaultValue = "0") int institutionId,
			@CookieValue(value = "courseId", defaultValue = "0") int courseId) {

		if (bindingResult.hasErrors()) {

			return "addStudentPage";
		} else {

			Institution institution = zerakiService.findUsingInstitutionId(institutionId);
			Course course = zerakiService.findUsingCourseId(courseId);

			student.setInstitution(institution);
			student.setCourse(course);

			zerakiService.saveStudent(student);
			return "redirect:/listStudents";

		}

	}

	// sending studentList page to the browser on refresh
	@RequestMapping("/listStudents")
	public String studentList(@CookieValue(value = "courseId", defaultValue = "0") int courseId, ModelMap modelMap,
			HttpServletResponse response) {

		Cookie cookie = new Cookie("courseId", String.valueOf(courseId));
		response.addCookie(cookie);
		Course course = zerakiService.findUsingCourseId(courseId);
		List<Student> students = course.getStudents();
		modelMap.addAttribute("students", students);

		return "studentListPage";
	}

	// delete student
	@RequestMapping("/deleteStudent")
	public String deleteStudent(@RequestParam("studentId") int studentId) {

		Student student = zerakiService.findUsingStudentId(studentId);

		zerakiService.deleteStudent(student);

		return "redirect:/listStudents";

	}

	// edit student
	@RequestMapping("/editStudent")
	public String showEditStudentPage(@RequestParam("studentId") int studentId, ModelMap modelMap,
			HttpServletResponse response) {

		Student student = zerakiService.findUsingStudentId(studentId);

		Cookie cookie = new Cookie("studentId", String.valueOf(studentId));

		response.addCookie(cookie);

		modelMap.addAttribute("student", student);

		return "editStudentPage";

	}

	// edit the student
	@RequestMapping("/editStudentAction")
	public String editStudentAction(@Valid @ModelAttribute("student") Student student, BindingResult bindingResult,
			ModelMap modelMap, @CookieValue(value = "studentId", defaultValue = "0") int studentId) {

		if (bindingResult.hasErrors()) {

			return "editStudentPage";
		} else {

			Student studentDb = zerakiService.findUsingStudentId(studentId);

			studentDb.setStudentName(student.getStudentName());

			zerakiService.saveStudent(studentDb);
			return "redirect:/listStudents";
		}

	}

	// change course
	@RequestMapping("/changeCourse")
	public String showChangeCoursePage(@ModelAttribute("course") Course course, BindingResult bindingResult,
			@RequestParam("studentId") int studentId, ModelMap modelMap, HttpServletResponse response) {

		Student student = zerakiService.findUsingStudentId(studentId);

		Cookie cookie = new Cookie("studentId", String.valueOf(studentId));

		response.addCookie(cookie);

		modelMap.addAttribute("student", student);

		return "changeCoursePage";

	}

	// saving the course
	@RequestMapping("/changeCourseAction")
	public String changeCourse(@Valid @ModelAttribute("course") Course course, BindingResult bindingResult,
			ModelMap modelMap, @CookieValue(value = "studentId", defaultValue = "0") int studentId) {

		if (bindingResult.hasErrors()) {

			return "changeCoursePage";
		} else {

			if (zerakiService.findCourseUsingName(course.getCourseName()) == null) {

				modelMap.addAttribute("msg", "Course does not exist please try again");

				return "changeCoursePage";
			} else {
				Course courseDb = zerakiService.findCourseUsingName(course.getCourseName());
				Student studentDb = zerakiService.findUsingStudentId(studentId);

				studentDb.setCourse(courseDb);

				zerakiService.saveStudent(studentDb);

				return "redirect:/listStudents";

			}

		}
	}

	// Transfer page to browser
	@RequestMapping("/transfer")
	public String showTrasferPage(@ModelAttribute("institution") Institution institution, BindingResult bindingResult,
			@RequestParam("studentId") int studentId, ModelMap modelMap, HttpServletResponse response) {

		Student student = zerakiService.findUsingStudentId(studentId);

		Cookie cookie = new Cookie("studentId", String.valueOf(studentId));

		response.addCookie(cookie);

		modelMap.addAttribute("student", student);

		return "transferPage";

	}

	// saving the transfer
	@RequestMapping("/transferAction")
	public String transferAction(@Valid @ModelAttribute("institution") Institution institution,
			BindingResult bindingResult, ModelMap modelMap,
			@CookieValue(value = "studentId", defaultValue = "0") int studentId) {

		if (bindingResult.hasErrors()) {

			System.out.println(1);
			return "transferPage";
		} else {

			if (zerakiService.findInstitutionUsingName(institution.getInstitutionName()) == null) {

				modelMap.addAttribute("msg", "Institution does not exist please try again");
				System.out.println(2);

				return "transferPage";
			} else {
				Institution institutionDb = zerakiService.findInstitutionUsingName(institution.getInstitutionName());
				Student studentDb = zerakiService.findUsingStudentId(studentId);

				studentDb.setInstitution(institutionDb);

				zerakiService.saveStudent(studentDb);

				System.out.println(3);
				return "redirect:/listStudents";

			}

		}
	}

}
