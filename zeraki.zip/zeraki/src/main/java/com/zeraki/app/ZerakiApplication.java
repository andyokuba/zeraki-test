package com.zeraki.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZerakiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZerakiApplication.class, args);
	}

}
