package com.zeraki.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zeraki.app.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

	// find student using id
	Student findByStudentId(int studentId);

}
