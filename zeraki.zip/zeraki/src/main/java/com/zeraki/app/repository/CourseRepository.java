package com.zeraki.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zeraki.app.model.Course;

public interface CourseRepository extends JpaRepository<Course, Integer> {

	// find course using course name
	Course findCourseByCourseName(String courseName);

	// find course using course Id
	Course findByCourseId(int courseId);

}
