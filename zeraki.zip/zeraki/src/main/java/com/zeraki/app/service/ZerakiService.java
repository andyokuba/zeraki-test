package com.zeraki.app.service;

import java.util.List;

import javax.validation.Valid;

import com.zeraki.app.model.Course;
import com.zeraki.app.model.Institution;
import com.zeraki.app.model.Student;

public interface ZerakiService {

	// find institution using name
	Institution findInstitutionUsingName(String institutionName);

	// save institution
	void saveInstitution(@Valid Institution institution);

	// finds all institutions
	List<Institution> findAllInstitutions();

	// find institution Using id
	Institution findUsingInstitutionId(int institutionId);

	// delete institution
	void deleteInstitution(Institution institution);

	// find course using course name
	Course findCourseUsingName(String courseName);

	// save course
	void saveCourse(@Valid Course course);

	// find course using course Id
	Course findUsingCourseId(int courseId);

	// delete course
	void deleteCourse(Course course);

	// save student
	void saveStudent(@Valid Student student);

	// find student using id
	Student findUsingStudentId(int studentId);

	// delete student
	void deleteStudent(Student student);

}
