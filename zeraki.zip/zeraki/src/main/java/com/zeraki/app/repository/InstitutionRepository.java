package com.zeraki.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zeraki.app.model.Institution;

public interface InstitutionRepository extends JpaRepository<Institution, Integer> {

	// find institution using name
	Institution findByInstitutionNameIgnoreCase(String institutionName);

	// find institution Using id
	Institution findByInstitutionId(int institutionId);

}
